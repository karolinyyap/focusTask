
package view;

import controller.GerenciadorInterface;

/**
 *
 * @author Karoliny
 */
public class FrmPrincipal extends javax.swing.JFrame {

 
    public FrmPrincipal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundoTitulo16 = new javax.swing.JPanel();
        tituloGerenciador16 = new javax.swing.JLabel();
        tituloFocus16 = new javax.swing.JLabel();
        fundoBtn = new javax.swing.JPanel();
        btnTarefas = new javax.swing.JButton();
        btnEquipes = new javax.swing.JButton();
        btnCategorias = new javax.swing.JButton();
        btnUsuarios = new javax.swing.JButton();
        btnRelatorios = new javax.swing.JButton();
        panelFundoUsuario = new javax.swing.JPanel();
        btnEntrarPrincipal = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("FocusTask");
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        fundoTitulo16.setBackground(new java.awt.Color(204, 204, 204));
        fundoTitulo16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tituloGerenciador16.setFont(new java.awt.Font("Source Sans Pro Black", 1, 24)); // NOI18N
        tituloGerenciador16.setText("GERENCIADOR DE TAREFAS");

        tituloFocus16.setFont(new java.awt.Font("Source Sans Pro Black", 0, 18)); // NOI18N
        tituloFocus16.setText("FOCUS TASK");

        javax.swing.GroupLayout fundoTitulo16Layout = new javax.swing.GroupLayout(fundoTitulo16);
        fundoTitulo16.setLayout(fundoTitulo16Layout);
        fundoTitulo16Layout.setHorizontalGroup(
            fundoTitulo16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoTitulo16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(fundoTitulo16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoTitulo16Layout.createSequentialGroup()
                        .addComponent(tituloGerenciador16)
                        .addGap(96, 96, 96))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoTitulo16Layout.createSequentialGroup()
                        .addComponent(tituloFocus16)
                        .addGap(213, 213, 213))))
        );
        fundoTitulo16Layout.setVerticalGroup(
            fundoTitulo16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoTitulo16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tituloGerenciador16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tituloFocus16)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        fundoBtn.setBackground(new java.awt.Color(204, 204, 204));
        fundoBtn.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnTarefas.setBackground(new java.awt.Color(153, 153, 153));
        btnTarefas.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        btnTarefas.setText("TAREFAS");
        btnTarefas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnTarefas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTarefasMouseClicked(evt);
            }
        });
        btnTarefas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTarefasActionPerformed(evt);
            }
        });

        btnEquipes.setBackground(new java.awt.Color(153, 153, 153));
        btnEquipes.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        btnEquipes.setText("EQUIPES");
        btnEquipes.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEquipes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEquipesActionPerformed(evt);
            }
        });

        btnCategorias.setBackground(new java.awt.Color(153, 153, 153));
        btnCategorias.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        btnCategorias.setText("CATEGORIAS");
        btnCategorias.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCategorias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCategoriasActionPerformed(evt);
            }
        });

        btnUsuarios.setBackground(new java.awt.Color(153, 153, 153));
        btnUsuarios.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        btnUsuarios.setText("USUÁRIOS");
        btnUsuarios.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsuariosActionPerformed(evt);
            }
        });

        btnRelatorios.setBackground(new java.awt.Color(153, 153, 153));
        btnRelatorios.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        btnRelatorios.setText("RELATÓRIOS");
        btnRelatorios.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRelatorios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRelatoriosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout fundoBtnLayout = new javax.swing.GroupLayout(fundoBtn);
        fundoBtn.setLayout(fundoBtnLayout);
        fundoBtnLayout.setHorizontalGroup(
            fundoBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoBtnLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnTarefas, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEquipes, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoBtnLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCategorias, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btnRelatorios, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(111, 111, 111))
        );
        fundoBtnLayout.setVerticalGroup(
            fundoBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoBtnLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(fundoBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTarefas, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEquipes, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(fundoBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnRelatorios, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                    .addComponent(btnCategorias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        panelFundoUsuario.setBackground(new java.awt.Color(204, 204, 204));
        panelFundoUsuario.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnEntrarPrincipal.setBackground(new java.awt.Color(153, 153, 153));
        btnEntrarPrincipal.setText("Entrar");
        btnEntrarPrincipal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrarPrincipalActionPerformed(evt);
            }
        });

        btnSair.setBackground(new java.awt.Color(153, 153, 153));
        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFundoUsuarioLayout = new javax.swing.GroupLayout(panelFundoUsuario);
        panelFundoUsuario.setLayout(panelFundoUsuarioLayout);
        panelFundoUsuarioLayout.setHorizontalGroup(
            panelFundoUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFundoUsuarioLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(btnEntrarPrincipal, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        panelFundoUsuarioLayout.setVerticalGroup(
            panelFundoUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFundoUsuarioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelFundoUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEntrarPrincipal)
                    .addComponent(btnSair))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(fundoBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fundoTitulo16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(29, Short.MAX_VALUE))
            .addComponent(panelFundoUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelFundoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(fundoTitulo16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(fundoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEntrarPrincipalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarPrincipalActionPerformed
        GerenciadorInterface.getMyInstance().abrirLogin();
    }//GEN-LAST:event_btnEntrarPrincipalActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnRelatoriosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatoriosActionPerformed
        GerenciadorInterface.getMyInstance().abrirRelatorio();
    }//GEN-LAST:event_btnRelatoriosActionPerformed

    private void btnUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsuariosActionPerformed
        GerenciadorInterface.getMyInstance().abrirUsuario();
    }//GEN-LAST:event_btnUsuariosActionPerformed

    private void btnCategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoriasActionPerformed
        GerenciadorInterface.getMyInstance().abrirCategoria();
    }//GEN-LAST:event_btnCategoriasActionPerformed

    private void btnEquipesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEquipesActionPerformed
        GerenciadorInterface.getMyInstance().abrirEquipe();
    }//GEN-LAST:event_btnEquipesActionPerformed

    private void btnTarefasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTarefasActionPerformed
        GerenciadorInterface.getMyInstance().abrirTarefa();
    }//GEN-LAST:event_btnTarefasActionPerformed

    private void btnTarefasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTarefasMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTarefasMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCategorias;
    private javax.swing.JButton btnEntrarPrincipal;
    private javax.swing.JButton btnEquipes;
    private javax.swing.JButton btnRelatorios;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnTarefas;
    private javax.swing.JButton btnUsuarios;
    private javax.swing.JPanel fundoBtn;
    private javax.swing.JPanel fundoTitulo16;
    private javax.swing.JPanel panelFundoUsuario;
    private javax.swing.JLabel tituloFocus16;
    private javax.swing.JLabel tituloGerenciador16;
    // End of variables declaration//GEN-END:variables
}
